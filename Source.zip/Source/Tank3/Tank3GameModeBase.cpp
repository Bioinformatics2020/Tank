// Copyright Epic Games, Inc. All Rights Reserved.


#include "Tank3GameModeBase.h"
#include <Kismet/GameplayStatics.h>

#include <TankPawnBase.h>

#define TANK_PC_PATH "Blueprint'/Game/Blueprint/BP_TankPC.BP_TankPC_C'"
#define TANK_PAWN_PATH "Blueprint'/Game/Blueprint/BP_TankPawnBase.BP_TankPawnBase_C'"

ATank3GameModeBase::ATank3GameModeBase()
{
	ConstructorHelpers::FClassFinder<APlayerController> TankPCFinder(TEXT(TANK_PC_PATH));
	checkf(TankPCFinder.Succeeded(), TEXT("Load %s error"), TANK_PC_PATH);
	PlayerControllerClass = TankPCFinder.Class;

	ConstructorHelpers::FClassFinder<APawn> TankPawnFinder(TEXT(TANK_PAWN_PATH));
	checkf(TankPawnFinder.Succeeded(), TEXT("Load %s error"), TANK_PAWN_PATH);
	DefaultPawnClass = TankPawnFinder.Class;
}

void ATank3GameModeBase::BeginPlay()
{
	TArray<AActor*> AllEnemyTankAcor;
	UGameplayStatics::GetAllActorsOfClassWithTag(this, ATankPawnBase::StaticClass(), TEXT("Enemy"), AllEnemyTankAcor);
	for (AActor* EnemyTankActor:AllEnemyTankAcor)
	{
		AllEnemyTank.Add(Cast<ATankPawnBase>(EnemyTankActor));
	}
}

ATankPawnBase* ATank3GameModeBase::GetNearOfDirection(FVector NowLocation, FRotator NowRotator)
{
	ATankPawnBase* NearEnemyTank = NULL;
	FVector Rotator = NowRotator.Vector();
	float NearValue = 1e10;
	for (ATankPawnBase* EnemyTank : AllEnemyTank)
	{
		if (!IsValid(EnemyTank))
		{
			continue;
		}
		FVector EnemyLocation = EnemyTank->GetActorLocation();
		EnemyLocation.Z += 200;
		FHitResult HitResult;
		UKismetSystemLibrary::LineTraceSingle(this, NowLocation, EnemyLocation, UEngineTypes::ConvertToTraceType(ECC_Visibility), false, {}, EDrawDebugTrace::ForOneFrame, HitResult, true);
		if (HitResult.bBlockingHit && HitResult.Actor->ActorHasTag(TEXT("Enemy")))
		{
			float Value = ((EnemyLocation - NowLocation).Size() * Rotator - EnemyLocation).Size();
			if (Value<NearValue)
			{
				NearValue = Value;
				NearEnemyTank = EnemyTank;
			}
		}
	}
	return NearEnemyTank;
}
