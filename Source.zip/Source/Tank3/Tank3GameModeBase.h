// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "Tank3GameModeBase.generated.h"

/**
 * 
 */
UCLASS()
class TANK3_API ATank3GameModeBase : public AGameModeBase
{
	GENERATED_BODY()
public:
	ATank3GameModeBase();

	virtual void BeginPlay() override;

	UPROPERTY(EditAnywhere,BlueprintReadWrite)
		TArray<class ATankPawnBase*> AllEnemyTank;

	ATankPawnBase* GetNearOfDirection(FVector NowLocation, FRotator NowRotator);
};
