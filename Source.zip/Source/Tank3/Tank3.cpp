// Copyright Epic Games, Inc. All Rights Reserved.

#include "Tank3.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, Tank3, "Tank3" );
