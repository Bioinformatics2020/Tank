// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/PlayerController.h"
#include "TankPC.generated.h"

/**
 * 
 */
UCLASS()
class TANK3_API ATankPC : public APlayerController
{
	GENERATED_BODY()
public:
	FVector GetAimWorldLocation();

	virtual void OnPossess(APawn* aPawn) override;
	virtual void PlayerTick(float DeltaTime) override;

private:
	class ATankPawnBase* TankPawn;
	class ATank3GameModeBase* TankGM;
};
