// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Pawn.h"
#include "TankPawnBase.generated.h"

UCLASS()
class TANK3_API ATankPawnBase : public APawn
{
	GENERATED_BODY()

public:
	// Sets default values for this pawn's properties
	ATankPawnBase();

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

public:	
	// Called every frame
	virtual void Tick(float DeltaTime) override;

public:
	//��Ӧ����
	virtual void SetupPlayerInputComponent(class UInputComponent* PlayerInputComponent) override;

	//AxisInput
	void LookUp(float AxisValue);
	void LookRight(float AxisValue);
	void AddMoveForward(float AxisValue);
	void AddMoveRight(float AxisValue);
	//ActionInput
	void ZoomUp();
	void ZoomDown();
	void StartAim();
	void EndAim();
	void StartFire();
	void EndFire();
	void ReLoad();
	void AutoAim();
	void StartHandBrake();
	void EndHandBrake();

//����
public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		class USkeletalMeshComponent* TankBody;

public:
	//�������ز���
	void InitCamera();

	//��׼�����
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = CameraSystem)
		class USpringArmComponent* CameraArm;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = CameraSystem)
		class UCameraComponent* CameraTP;
	//��̨��λ�����
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = CameraSystem)
		class USpringArmComponent* CameraArmAim;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = CameraSystem)
		class UCameraComponent* CameraAim;

private:
	void UpdateCamera(float DeltaTime);

	float TargetArmLength;
	float TargetFieldOfView;

//�������
public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Health)
		class UHealthComponent* HealthComponent;

//�˶����
public:
	UFUNCTION(BlueprintCallable)
		void SpawnDust();

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = TankMove)
		class UTankMoveComponent* TankMoveComponent;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = TankMove)
		TArray<FName> LeftWheelBone;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = TankMove)
		TArray<FName> RightWheelBone;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = TankMove)
		TArray<float> LeftWheelOffest;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = TankMove)
		TArray<float> RightWheelOffest;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = TankMove)
		class UParticleSystem* MoveEmitter;

private:
	void InitTankMoveComponent();

	float InputForwardValue;
	float InputRightValue;
	float LastSpawnDustTime = 0.2;

//������
public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = FireSystem)
		class UFireSystemComponent* FireSystemComponent;

//��̨��ת���
public:
	UFUNCTION(BlueprintCallable)
		bool GetTurretRotation(float &OutYawRotator, float &OutPitchRotator);
	UFUNCTION(BlueprintCallable)
		void SetAimLocation(FVector InAimLocation);

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = FireSystem)
		class UTurretComponent* TurretComponent;
	bool bAutoAim;

private:
	float TurretYawRotator;
	float TurretPitchRotator;
	bool bTurretCanRotator;
	FVector AimLocation;
};
