// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "FireSystemComponent.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE(FDelegateFire);

USTRUCT(BlueprintType)
struct FBulletInfo
{
	GENERATED_BODY();

	FBulletInfo() {};

	UPROPERTY(EditAnywhere,BlueprintReadWrite)
		UClass* BulletClass;
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		class UParticleSystem* FireEmitter;
	UPROPERTY(EditAnywhere,BlueprintReadWrite)
		float FireInterval;//������
	UPROPERTY(EditAnywhere,BlueprintReadWrite)
		int MaxMagazineBulletNum;//��������ӵ���
	UPROPERTY(EditAnywhere,BlueprintReadWrite)
		int NowMagazineBulletNum;//��ǰ�����ӵ���
	UPROPERTY(EditAnywhere,BlueprintReadWrite)
		int MaxBullet;//����ӵ���
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int NowBullet;//��ǰ�ӵ���
};

UCLASS( ClassGroup=(Custom), meta=(BlueprintSpawnableComponent) )
class TANK3_API UFireSystemComponent : public UActorComponent
{
	GENERATED_BODY()

public:	
	// Sets default values for this component's properties
	UFireSystemComponent();

	UFUNCTION(BlueprintCallable)
		void Init(FName InGunBone, const TArray<FBulletInfo> InBulletInfos);

	UFUNCTION(BlueprintCallable)
		void SetAutoFire(bool bInCanAutoFire);

	UFUNCTION(BlueprintCallable)
		const FBulletInfo& GetBulletInfo();
	virtual void BeginPlay() override;
	// Called every frame
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

	UFUNCTION(BlueprintCallable)
		void StartFire();
	UFUNCTION(BlueprintCallable)
		void EndFire();
	UFUNCTION(BlueprintCallable)
		void Reload();
	UFUNCTION(BlueprintCallable)
		bool AddBullet(int Index, int Num);

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		TArray<FBulletInfo> BulletInfos;

	UPROPERTY(EditAnywhere, BlueprintAssignable)
		FDelegateFire OnFire;

private:
	bool NoBullet;
	bool Start;
	bool bCanAutoFire = true;
	float NextFireInterval = 0;
	class USceneComponent* Body;
	FName GunBone;
	int NowBulletIndex = 0;
};
