// Fill out your copyright notice in the Description page of Project Settings.


#include "../Component/MultiWheelMoveComponent.h"
#include <Kismet/KismetSystemLibrary.h>
#include <Kismet/KismetMathLibrary.h>

// Sets default values for this component's properties
UMultiWheelMoveComponent::UMultiWheelMoveComponent()
{
	// Set this component to be initialized when the game starts, and to be ticked every frame.  You can turn these features
	// off to improve performance if you don't need them.
	PrimaryComponentTick.bCanEverTick = true;

	// ...
}


// Called when the game starts
void UMultiWheelMoveComponent::BeginPlay()
{
	Super::BeginPlay();

	// ...
	
}

void UMultiWheelMoveComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	bWheelContact = 0;
	for (int i = 0; i < WheelsGroups.Num(); i++)
	{
		float ControlInput = WheelGroupsControlInput[i];
		for (int j = 0; j < WheelsGroups[i].wheelsArray.Num(); j++)
		{
			WheelCompute(ControlInput, WheelsGroups[i].wheelsArray[j],
				WheelsGroups[i].SuspensionDumping, WheelsGroups[i].SuspensionStiffness,
				WheelsGroups[i].rootSimulatedComponent, WheelsGroups[i].RootSimulatedBone);
		}
	}
}

FVector UMultiWheelMoveComponent::GetWheelVelocity(int IndexGroup, int IndexWheel)
{
	if (WheelsGroups.IsValidIndex(IndexGroup) && WheelsGroups[IndexGroup].wheelsArray.IsValidIndex(IndexWheel))
	{
		return WheelsGroups[IndexGroup].wheelsArray[IndexWheel].WheelVelocity;
	}
	else
	{
		return FVector::ZeroVector;
	}
}

float UMultiWheelMoveComponent::GetWheelOffset(int IndexGroup, int IndexWheel)
{
	if (WheelsGroups.IsValidIndex(IndexGroup) && WheelsGroups[IndexGroup].wheelsArray.IsValidIndex(IndexWheel))
	{
		return WheelsGroups[IndexGroup].wheelsArray[IndexWheel].LastContactDistance;
	}
	else
	{
		return 0;
	}
}

void UMultiWheelMoveComponent::WheelCompute(float ControlInput, FWheelData& CurretWheel, float Dumping, float Stiffness, UPrimitiveComponent* Body, FName Bone)
{

	//���μ��
	FVector Start = CurretWheel.wheelRootEmpty->GetComponentLocation();
	FVector End = Start - CurretWheel.wheelRootEmpty->GetUpVector()*(WheelMaxContactDistance + WheelRadius);
	FHitResult OutHit;
	UKismetSystemLibrary::SphereTraceSingleForObjects(this, Start, End, WheelRadius, TreceForObjectTypes, false, {}, EDrawDebugTrace::None, OutHit, true);

// 	UKismetSystemLibrary::DrawDebugLine(this, Start, End, FLinearColor::Red, 0, 2);
// 	UKismetSystemLibrary::DrawDebugSphere(this, OutHit.Location, 30);

	if (!OutHit.bBlockingHit)
	{
		CurretWheel.WheelVelocity = FVector(0, 0, 0);
		return;
	}

	bWheelContact = true;
	OutHit.Distance = FMath::Clamp(OutHit.Distance, WheelMinContactDistance, WheelMaxContactDistance);

	//���㳵�ֵ��ٶ�
	FVector WheelLocation = CurretWheel.wheelRootEmpty->GetComponentLocation();
	FVector WheelVelocity = Body->GetPhysicsLinearVelocityAtPoint(WheelLocation, Bone);
	if (OutHit.Component.IsValid(false) && OutHit.Component->IsSimulatingPhysics(OutHit.BoneName))
	{
		FVector HitVelocity = OutHit.Component->GetPhysicsLinearVelocityAtPoint(WheelLocation, OutHit.BoneName);
		WheelVelocity -= HitVelocity;
	}
	CurretWheel.WheelVelocity = UKismetMathLibrary::TransformDirection(CurretWheel.wheelRootEmpty->GetComponentTransform().Inverse(), WheelVelocity);
	CurretWheel.LastContactDistance = OutHit.Distance;

	//����������
	FVector SpringBase = GetOwner()->GetActorUpVector() * (CurretWheel.WheelVelocity.Z * Dumping * -0.8 + (WheelDefaultDistance - OutHit.Distance) * Stiffness * 15);
	FVector SpringForce(0, 0, 0);
	SpringForce.Z = SpringBase.Z;


	//���������
	FVector FrictionForce = UKismetMathLibrary::Dot_VectorVector(GetOwner()->GetVelocity(),GetOwner()->GetActorRightVector()) * WheelFrictionMultipler * -5000 * CurretWheel.wheelRootEmpty->GetRightVector();
	//��ֹת�����
	FrictionForce += CurretWheel.WheelVelocity.Y * WheelFrictionMultipler * -2000 * CurretWheel.wheelRootEmpty->GetRightVector();
	
	//����ǰ����
	float BaseForce = 0;
	if (bBrake)
	{
		BaseForce = CurretWheel.WheelVelocity.X > 0? -1600: 1600;
		if (CurretWheel.WheelVelocity.X<10 && CurretWheel.WheelVelocity.X > -10)
		{
			BaseForce /= 100;
		}
		else if (CurretWheel.WheelVelocity.X<2 && CurretWheel.WheelVelocity.X > -2)
		{
			BaseForce = 0;
		}
	} 
	else
	{
		BaseForce = ControlInput * 800;
		BaseForce -= UKismetMathLibrary::MapRangeClamped(CurretWheel.WheelVelocity.X, -WheelMaxSpeed*2, WheelMaxSpeed*2, -800, 800);
	}
	if (CurretWheel.WheelVelocity.X > 50 || CurretWheel.WheelVelocity.X < -50)
	{
		BaseForce -= CurretWheel.WheelVelocity.X * 800 / (WheelMaxSpeed*2);
	}
	else
	{
		BaseForce -= CurretWheel.WheelVelocity.X;
	}
	FVector MoveForce = CurretWheel.wheelRootEmpty->GetForwardVector() * (BaseForce * 100 * (OutHit.Normal.Z + 1) * WheelMoveForceMultipler);

	//ʩ�Ӻ���
	FVector Force = SpringForce + FrictionForce + MoveForce;
	Body->AddForceAtLocation(Force, WheelLocation, Bone);

	if (OutHit.Component.IsValid(false) && OutHit.Component->IsSimulatingPhysics(OutHit.BoneName))
	{
		FVector HitForce = UKismetMathLibrary::ClampVectorSize(-Force, 0, 800 * OutHit.Component->GetMass());
		OutHit.Component->AddForceAtLocation(HitForce, OutHit.ImpactPoint, OutHit.BoneName);
	}

	//UKismetSystemLibrary::PrintString(this, FString::Printf(TEXT("Force:%s"), *Force.ToString()), true, false, FLinearColor::Red, 0);
}