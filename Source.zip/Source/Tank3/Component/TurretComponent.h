// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "TurretComponent.generated.h"


UCLASS( ClassGroup=(Custom), meta=(BlueprintSpawnableComponent) )
class TANK3_API UTurretComponent : public UActorComponent
{
	GENERATED_BODY()

public:	
	// Sets default values for this component's properties
	UTurretComponent();

protected:
	// Called when the game starts
	virtual void BeginPlay() override;

public:	
	UFUNCTION(BlueprintCallable)
		void Init(FName InBaseBone, FName InFireBone, float InBaseRotatorSpeed, float InFireRotatorSpeed, FVector2D InYawClamp, FVector2D InPitchClamp);

	// Called every frame
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;
	bool TargetRotation(float DeltaTime, FVector TargetLocation, float &OutYawRotator, float &OutPitchRotator);

private:
	class USceneComponent* Body;

	FName BaseBone;
	FName FireBone;
	float BaseRotatorSpeed;
	float FireRotatorSpeed;
	FVector2D YawClamp;
	FVector2D PitchClamp;
};
