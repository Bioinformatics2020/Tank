// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "MultiWheelMoveComponent.generated.h"


USTRUCT(BlueprintType)
struct  FWheelData
{
	GENERATED_BODY()
public:
	FWheelData() {}
	FWheelData(USceneComponent* InWheelRootEmpty, FVector InWheelVelocity, float InLastContactDistance):
		wheelRootEmpty(InWheelRootEmpty), WheelVelocity(InWheelVelocity), LastContactDistance(InLastContactDistance){}

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		USceneComponent* wheelRootEmpty;
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FVector WheelVelocity;
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float LastContactDistance;
};

USTRUCT(BlueprintType)
struct FWheelsGroups
{
	GENERATED_BODY()

		FWheelsGroups() {}

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		TArray<FWheelData> wheelsArray;
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float SuspensionDumping;
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float SuspensionStiffness;
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		UPrimitiveComponent* rootSimulatedComponent;
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		FName RootSimulatedBone;
};


UCLASS( ClassGroup=(Custom), meta=(BlueprintSpawnableComponent) )
class TANK3_API UMultiWheelMoveComponent : public UActorComponent
{
	GENERATED_BODY()

public:	
	// Sets default values for this component's properties
	UMultiWheelMoveComponent();

protected:
	// Called when the game starts
	virtual void BeginPlay() override;

public:	
	// Called every frame
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

public:
	UFUNCTION(BlueprintCallable)
		bool GetWheelContact() { return bWheelContact; }
	UFUNCTION(BlueprintCallable)
		void SetBrake(bool InBrake) { bBrake = InBrake; }
	UFUNCTION(BlueprintCallable)
		FVector GetWheelVelocity(int IndexGroup, int IndexWheel);
	UFUNCTION(BlueprintCallable)
		float GetWheelOffset(int IndexGroup, int IndexWheel);


	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float WheelRadius;
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float WheelDefaultDistance;
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float WheelMaxContactDistance;
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float WheelMinContactDistance;
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float WheelMoveForceMultipler = 1;
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float WheelFrictionMultipler = 1;
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float WheelSlideResist = 1;
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		float WheelMaxSpeed = 3000;
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		TArray<TEnumAsByte<EObjectTypeQuery>> TreceForObjectTypes;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		TArray<FWheelsGroups> WheelsGroups;
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		TArray<float> WheelGroupsControlInput;

protected:
	void WheelCompute(float ControlInput, FWheelData& CurretWheel, float Dumping, float Stiffness, UPrimitiveComponent* Body, FName Bone);

	bool bWheelContact;
	bool bBrake;
};
