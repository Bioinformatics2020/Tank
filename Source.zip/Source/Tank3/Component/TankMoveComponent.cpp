// Fill out your copyright notice in the Description page of Project Settings.


#include "../Component/TankMoveComponent.h"
#include <Kismet/KismetSystemLibrary.h>

// Sets default values for this component's properties
UTankMoveComponent::UTankMoveComponent()
{
	// Set this component to be initialized when the game starts, and to be ticked every frame.  You can turn these features
	// off to improve performance if you don't need them.
	PrimaryComponentTick.bCanEverTick = true;

	WheelRadius = 30;
	WheelDefaultDistance = 56;
	WheelMaxContactDistance = 80;
	WheelMinContactDistance = 20;
	WheelMoveForceMultipler = 3;

	TreceForObjectTypes.Reset(3);
	TreceForObjectTypes.Add(TEnumAsByte<EObjectTypeQuery>(ECollisionChannel::ECC_WorldStatic));
	TreceForObjectTypes.Add(TEnumAsByte<EObjectTypeQuery>(ECollisionChannel::ECC_WorldDynamic));
	TreceForObjectTypes.Add(TEnumAsByte<EObjectTypeQuery>(ECollisionChannel::ECC_Pawn));

	WheelGroupsControlInput.SetNumZeroed(2, true);

	WheelMaxSpeed = 2000;
	// ...
}


// Called when the game starts
void UTankMoveComponent::BeginPlay()
{
	Super::BeginPlay();

	// ...
	
}


// Called every frame
void UTankMoveComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	// ...
}

void UTankMoveComponent::Init(TArray<USceneComponent*> LeftwheelsComponent, TArray<USceneComponent*> RightwheelsComponent, UPrimitiveComponent* rootComponent, float SuspensionDumping, float SuspensionStiffness)
{
	TArray<FWheelData> Leftwheels;
	TArray<FWheelData> Rightwheels;
	Leftwheels.Reserve(LeftwheelsComponent.Num());
	Rightwheels.Reserve(RightwheelsComponent.Num());

	for (USceneComponent* WheelComponent : LeftwheelsComponent)
	{
		Leftwheels.Add(FWheelData(WheelComponent, { 0,0,0 }, WheelDefaultDistance));
	}
	for (USceneComponent* WheelComponent : RightwheelsComponent)
	{
		Rightwheels.Add(FWheelData(WheelComponent, { 0,0,0 }, WheelDefaultDistance));
	}

	WheelsGroups.Reset(2);
	FWheelsGroups WheelGroups;
	WheelGroups.rootSimulatedComponent = rootComponent;
	WheelGroups.wheelsArray = Leftwheels;
	WheelGroups.SuspensionDumping = SuspensionDumping;
	WheelGroups.SuspensionStiffness = SuspensionStiffness;
	WheelsGroups.Add(WheelGroups);

	WheelGroups.wheelsArray = Rightwheels;
	WheelsGroups.Add(WheelGroups);
}

void UTankMoveComponent::TracksControl(float MoveForward, float MoveRight)
{
	int InputLeft = 0;
	int InputRight = 0;

	int SumInput = (MoveForward > 0 ? MoveForward : -MoveForward) + (MoveRight > 0 ? MoveRight : -MoveRight); 
	if (MoveForward < 0)
	{
		MoveRight *= -1;
	}
	if (SumInput > 1)
	{
		MoveForward /= SumInput;
		MoveRight /= SumInput;
	}
	InputLeft = MoveForward + MoveRight;
	InputRight = MoveForward - MoveRight;

	WheelGroupsControlInput[0] = InputLeft;
	WheelGroupsControlInput[1] = InputRight;
}


