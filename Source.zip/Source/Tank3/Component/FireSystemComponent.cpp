// Fill out your copyright notice in the Description page of Project Settings.


#include "../Component/FireSystemComponent.h"
#include <Kismet/KismetSystemLibrary.h>
#include <Components/SceneComponent.h>
#include "Kismet/GameplayStatics.h"

// Sets default values for this component's properties
UFireSystemComponent::UFireSystemComponent()
{
	// Set this component to be initialized when the game starts, and to be ticked every frame.  You can turn these features
	// off to improve performance if you don't need them.
	PrimaryComponentTick.bCanEverTick = true;

	// ...
}

void UFireSystemComponent::Init(FName InGunBone, const TArray<FBulletInfo> InBulletInfos)
{
	GunBone = InGunBone;
	if (InBulletInfos.Num() != 0)
	{
		BulletInfos = InBulletInfos;
	}

	Body = GetOwner()->GetRootComponent();
	check(Body);
}

void UFireSystemComponent::SetAutoFire(bool bInCanAutoFire)
{
	bCanAutoFire = bInCanAutoFire;
}

const FBulletInfo& UFireSystemComponent::GetBulletInfo()
{
	return BulletInfos[NowBulletIndex];
}

void UFireSystemComponent::BeginPlay()
{
	NoBullet = (BulletInfos.Num() <= 0);
	if (NoBullet)
	{
		UE_LOG(LogTemp, Warning, TEXT("%s BulletInfos is NULL"), __FUNCTION__);
	}
	for (auto &Info : BulletInfos)
	{
		if (Info.BulletClass == NULL ||
			Info.NowBullet > Info.MaxBullet ||
			Info.MaxMagazineBulletNum > Info.MaxBullet ||
			Info.MaxMagazineBulletNum <= 0)
		{
			UE_LOG(LogTemp, Warning, TEXT("%s BulletInfos is Error"), __FUNCTION__);
		}
	}
}

// Called every frame
void UFireSystemComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	if (NextFireInterval>0)
	{
		NextFireInterval -= DeltaTime;
		return;
	}

	if (!Start || NoBullet)
	{
		return;
	}

	if (BulletInfos[NowBulletIndex].NowMagazineBulletNum == 0)
	{
		return;
	}

	FTransform FireTransform = Body->GetSocketTransform(GunBone);
	FActorSpawnParameters ActorSpawnParameters;
	ActorSpawnParameters.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
	ActorSpawnParameters.Owner = this->GetOwner();
	AActor* Bullet = GetWorld()->SpawnActor<AActor>(BulletInfos[NowBulletIndex].BulletClass, FireTransform, ActorSpawnParameters);
	check(Bullet);
	BulletInfos[NowBulletIndex].NowMagazineBulletNum--;
	NextFireInterval += BulletInfos[NowBulletIndex].FireInterval;

	OnFire.Broadcast();

	if (BulletInfos[NowBulletIndex].FireEmitter != NULL)
	{
		UGameplayStatics::SpawnEmitterAtLocation(this->GetWorld(), BulletInfos[NowBulletIndex].FireEmitter, FireTransform, true, EPSCPoolMethod::AutoRelease,true);
	}

	if (!bCanAutoFire)
	{
		Start = false;
	}
}

void UFireSystemComponent::StartFire()
{
	Start = true;
}

void UFireSystemComponent::EndFire()
{
	Start = false;
	if (BulletInfos[NowBulletIndex].NowMagazineBulletNum == 0)
	{
		Reload();
	}
}

void UFireSystemComponent::Reload()
{
	int Diffent = BulletInfos[NowBulletIndex].MaxMagazineBulletNum - BulletInfos[NowBulletIndex].NowMagazineBulletNum;
	if (BulletInfos[NowBulletIndex].NowBullet == 0 || Diffent == 0)
	{
		return;
	}
	//����ʱ��
	NextFireInterval = 2;

	if (Diffent <= BulletInfos[NowBulletIndex].NowBullet)
	{
		BulletInfos[NowBulletIndex].NowMagazineBulletNum = BulletInfos[NowBulletIndex].MaxMagazineBulletNum;
		BulletInfos[NowBulletIndex].NowBullet -= Diffent;
	}
	else
	{
		BulletInfos[NowBulletIndex].NowMagazineBulletNum += BulletInfos[NowBulletIndex].NowBullet;
		BulletInfos[NowBulletIndex].NowBullet = 0;
	}
}

bool UFireSystemComponent::AddBullet(int Index, int Num)
{
	if (!BulletInfos.IsValidIndex(Index))
	{
		return false;
	}

	BulletInfos[NowBulletIndex].NowBullet += Num;

	if (BulletInfos[NowBulletIndex].NowBullet < 0)
	{
		BulletInfos[NowBulletIndex].NowBullet = 0;
		return false;
	}

	if (BulletInfos[NowBulletIndex].NowBullet > BulletInfos[NowBulletIndex].MaxBullet)
	{
		BulletInfos[NowBulletIndex].NowBullet = BulletInfos[NowBulletIndex].MaxBullet;
		return false;
	}
	return true;
}

