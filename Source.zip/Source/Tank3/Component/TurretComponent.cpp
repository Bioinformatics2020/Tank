// Fill out your copyright notice in the Description page of Project Settings.


#include "../Component/TurretComponent.h"
#include "Components/SceneComponent.h"
#include "Kismet/KismetMathLibrary.h"
#include "Kismet/KismetSystemLibrary.h"


// Sets default values for this component's properties
UTurretComponent::UTurretComponent()
{
	// Set this component to be initialized when the game starts, and to be ticked every frame.  You can turn these features
	// off to improve performance if you don't need them.
	PrimaryComponentTick.bCanEverTick = true;

	// ...
}


// Called when the game starts
void UTurretComponent::BeginPlay()
{
	Super::BeginPlay();

	// ...
	
}


void UTurretComponent::Init(FName InBaseBone, FName InFireBone, float InBaseRotatorSpeed, float InFireRotatorSpeed, FVector2D InYawClamp, FVector2D InPitchClamp)
{
	BaseBone = InBaseBone;
	FireBone = InFireBone;
	BaseRotatorSpeed = InBaseRotatorSpeed;
	FireRotatorSpeed = InFireRotatorSpeed;
	YawClamp = InYawClamp;
	PitchClamp = InPitchClamp;
	Body = GetOwner()->GetRootComponent();
}

// Called every frame
void UTurretComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	// ...
}

bool UTurretComponent::TargetRotation(float DeltaTime, FVector TargetLocation, float &OutYawRotator, float &OutPitchRotator)
{
	FTransform InverseTransform = Body->GetComponentTransform().Inverse();

	FVector BaseLocation = Body->GetSocketLocation(BaseBone);
	FRotator BaseRotation = UKismetMathLibrary::TransformRotation(InverseTransform, Body->GetSocketRotation(BaseBone));
	FRotator TargetBaseRotation = UKismetMathLibrary::TransformRotation(InverseTransform, (TargetLocation - BaseLocation).Rotation());
	float YawRotator = UKismetMathLibrary::RInterpTo(BaseRotation, TargetBaseRotation, DeltaTime, BaseRotatorSpeed).Yaw;
	OutYawRotator = UKismetMathLibrary::FClamp(YawRotator, YawClamp.X, YawClamp.Y);
	if (UKismetMathLibrary::NearlyEqual_FloatFloat(YawRotator,OutYawRotator,1))
	{
		OutYawRotator = YawRotator;
	}

	FVector FireLocation = Body->GetSocketLocation(FireBone);
	FRotator FireRotation = UKismetMathLibrary::TransformRotation(InverseTransform, Body->GetSocketRotation(FireBone));
	FRotator TargetFireRotation = UKismetMathLibrary::TransformRotation(InverseTransform, (TargetLocation - FireLocation).Rotation());
	float PitchRotator = UKismetMathLibrary::RInterpTo(FireRotation, TargetFireRotation, DeltaTime, FireRotatorSpeed).Pitch;
	if (UKismetMathLibrary::NearlyEqual_FloatFloat(PitchRotator, OutPitchRotator, 1))
	{
		OutPitchRotator = PitchRotator;
	}
	OutPitchRotator = UKismetMathLibrary::FClamp(PitchRotator, PitchClamp.X, PitchClamp.Y);

	//UKismetSystemLibrary::PrintString(this, FString::Printf(TEXT("BaseLocation:")) + BaseLocation.ToString(), true, false, FLinearColor::Red, 0);
	//UKismetSystemLibrary::PrintString(this, FString::Printf(TEXT("BaseRotation:"))+ BaseRotation.ToString(), true, false, FLinearColor::Red, 0);
	//UKismetSystemLibrary::PrintString(this, FString::Printf(TEXT("TargetBaseRotation:"))+ TargetBaseRotation.ToString(), true, false, FLinearColor::Red, 0);
	//UKismetSystemLibrary::PrintString(this, FString::Printf(TEXT("YawRotator: %f"), YawRotator), true, false, FLinearColor::Red, 0);
	//UKismetSystemLibrary::PrintString(this, FString::Printf(TEXT("OutYawRotator: %f"), OutYawRotator), true, false, FLinearColor::Red, 0);
	//UKismetSystemLibrary::PrintString(this, FString::Printf(TEXT(" ")), true, false, FLinearColor::Red, 0);
	//UKismetSystemLibrary::PrintString(this, FString::Printf(TEXT("FireLocation:")) + FireLocation.ToString(), true, false, FLinearColor::Red, 0);
	//UKismetSystemLibrary::PrintString(this, FString::Printf(TEXT("FireRotation:")) + FireRotation.ToString(), true, false, FLinearColor::Red, 0);
	//UKismetSystemLibrary::PrintString(this, FString::Printf(TEXT("TargetFireRotation:")) + TargetFireRotation.ToString(), true, false, FLinearColor::Red, 0);
	//UKismetSystemLibrary::PrintString(this, FString::Printf(TEXT("PitchRotator: %f"), PitchRotator), true, false, FLinearColor::Red, 0);
	//UKismetSystemLibrary::PrintString(this, FString::Printf(TEXT("OutPitchRotator: %f"), OutPitchRotator), true, false, FLinearColor::Red, 0);

	return OutYawRotator == YawRotator && OutPitchRotator == PitchRotator;
}

