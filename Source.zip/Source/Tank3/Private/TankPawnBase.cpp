// Fill out your copyright notice in the Description page of Project Settings.


#include "TankPawnBase.h"
#include "UObject/ConstructorHelpers.h"
#include "Components/SkeletalMeshComponent.h"
#include "GameFramework/SpringArmComponent.h"
#include "Camera/CameraComponent.h"

#include <../Component/HealthComponent.h>
#include <../Component/TankMoveComponent.h>
#include <../Component/FireSystemComponent.h>
#include <../Component/TurretComponent.h>
#include <Kismet/KismetMathLibrary.h>
#include <Kismet/KismetSystemLibrary.h>
#include "Kismet/GameplayStatics.h"

#define MeshPath "SkeletalMesh'/Game/VigilanteContent/Vehicles/West_Tank_M1A1Abrams/SK_West_Tank_M1A1Abrams.SK_West_Tank_M1A1Abrams'"

// Sets default values
ATankPawnBase::ATankPawnBase()
{
 	// Set this pawn to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;
	
	//����ģ��
	TankBody = CreateDefaultSubobject<USkeletalMeshComponent>(TEXT("TankBody"));
	ConstructorHelpers::FObjectFinder<USkeletalMesh> MeshComponentFinder(TEXT(MeshPath));
	checkf(MeshComponentFinder.Succeeded(), TEXT("Load %s error"), MeshPath);
	TankBody->SetSkeletalMesh(MeshComponentFinder.Object);
	SetRootComponent(TankBody);

	//����ActorComponent
	HealthComponent = CreateDefaultSubobject<UHealthComponent>(FName("HealthComponent"));
	TankMoveComponent = CreateDefaultSubobject<UTankMoveComponent>(FName("TankMoveComponent"));
	FireSystemComponent = CreateDefaultSubobject<UFireSystemComponent>(FName("FireSystemComponent"));
	TurretComponent = CreateDefaultSubobject<UTurretComponent>(FName("TurretComponent"));

	LeftWheelBone = { "lf_wheel_02_jnt", "lf_wheel_03_jnt", "lf_wheel_04_jnt", "lf_wheel_05_jnt", "lf_wheel_06_jnt", "lf_wheel_07_jnt", "lf_wheel_08_jnt", "lf_wheel_01_jnt", "lf_wheel_09_jnt" };
	RightWheelBone = { "rt_wheel_02_jnt","rt_wheel_03_jnt","rt_wheel_04_jnt","rt_wheel_05_jnt","rt_wheel_06_jnt","rt_wheel_07_jnt","rt_wheel_08_jnt","rt_wheel_01_jnt","rt_wheel_09_jnt" };

	TArray<FBulletInfo> InBulletInfos; 
	FireSystemComponent->Init(TEXT("gun_1_jntSocket"), {});
	TurretComponent->Init(TEXT("turret_jnt"), TEXT("gun_jnt"), 10, 10, { -180,180 }, { -5,45 });

	InitCamera();
}

void ATankPawnBase::InitCamera()
{
	//��׼�ӽǵ������
	CameraArm = CreateDefaultSubobject<USpringArmComponent>(FName("CameraArm"));
	CameraArm->AttachToComponent(TankBody, FAttachmentTransformRules::SnapToTargetIncludingScale);
	TargetArmLength = 1000;
	CameraArm->TargetArmLength = TargetArmLength;
	CameraArm->SocketOffset.Z = 300;
	CameraArm->bUsePawnControlRotation = true;
	CameraArm->SetRelativeLocation(FVector(0, 0, 200));

	CameraTP = CreateDefaultSubobject<UCameraComponent>(FName("CameraTP"));
	CameraTP->AttachToComponent(CameraArm, FAttachmentTransformRules::SnapToTargetIncludingScale);

	//��̨�ӽ�
	CameraArmAim = CreateDefaultSubobject<USpringArmComponent>(FName("CameraArmAim"));
	CameraArmAim->AttachToComponent(TankBody, FAttachmentTransformRules::SnapToTargetIncludingScale);
	CameraArmAim->TargetArmLength = 0;
	CameraArmAim->AddRelativeLocation(FVector(0, 0, 200));
	CameraArmAim->bUsePawnControlRotation = true;

	CameraAim = CreateDefaultSubobject<UCameraComponent>(FName("CameraAim"));
	TargetFieldOfView = 90;
	CameraAim->SetFieldOfView(TargetFieldOfView);
	CameraAim->AttachToComponent(CameraArmAim, FAttachmentTransformRules::SnapToTargetIncludingScale,TEXT("turret_jnt"));
}

void ATankPawnBase::UpdateCamera(float DeltaTime)
{
	if (CameraTP->IsActive())
	{
		CameraArm->TargetArmLength = UKismetMathLibrary::FInterpTo(CameraArm->TargetArmLength, TargetArmLength, DeltaTime, 5);
		if (TargetArmLength < 700 || TargetArmLength > 1500)
		{
			TargetArmLength = UKismetMathLibrary::FInterpTo(TargetArmLength, (TargetArmLength < 700) ? 700 : 1500, DeltaTime, 10);
		}
	}
	else
	{
		TargetFieldOfView = UKismetMathLibrary::FClamp(TargetFieldOfView, 30, 95);
		float FOV = UKismetMathLibrary::FInterpTo(CameraAim->FieldOfView, TargetFieldOfView, DeltaTime, 5);
		CameraAim->SetFieldOfView(FOV);
	}
}

void ATankPawnBase::SpawnDust()
{
	if (MoveEmitter == NULL)
		return;

	for (int i=0;i<LeftWheelBone.Num()-2;i++)
	{
		FVector SpawnLocation = TankBody->GetSocketLocation(LeftWheelBone[i]);
		SpawnLocation.Z -= TankMoveComponent->WheelRadius;
		float SpawnScale = TankMoveComponent->GetWheelVelocity(0, i).X / TankMoveComponent->WheelMaxSpeed * 2;
		UGameplayStatics::SpawnEmitterAtLocation(this, MoveEmitter, SpawnLocation, FRotator::ZeroRotator, FVector(SpawnScale), true, EPSCPoolMethod::AutoRelease);
	}
	for (int i = 0; i < RightWheelBone.Num() - 2; i++)
	{
		FVector SpawnLocation = TankBody->GetSocketLocation(RightWheelBone[i]);
		SpawnLocation.Z -= TankMoveComponent->WheelRadius;
		float SpawnScale = TankMoveComponent->GetWheelVelocity(1, i).X / TankMoveComponent->WheelMaxSpeed * 2;
		UGameplayStatics::SpawnEmitterAtLocation(this, MoveEmitter, SpawnLocation, FRotator::ZeroRotator, FVector(SpawnScale), true, EPSCPoolMethod::AutoRelease);
	}
}

void ATankPawnBase::InitTankMoveComponent()
{
	TArray<USceneComponent*> LeftScene;
	TArray<USceneComponent*> RightScene;
	for(FName &BoneName : LeftWheelBone)
	{
		FVector SocketLocation = TankBody->GetSocketLocation(BoneName);
		SocketLocation.Z += 30;
		FTransform SpawnTransform;
		SpawnTransform.SetLocation(UKismetMathLibrary::InverseTransformLocation(GetActorTransform(), SocketLocation));
		
		/*USceneComponent* SceneComponent = CreateDefaultSubobject<USceneComponent>(BoneName);
		SceneComponent->SetRelativeTransform(SpawnTransform);*/
		USceneComponent* SceneComponent = Cast<USceneComponent>(AddComponentByClass(USceneComponent::StaticClass(), false, SpawnTransform, false));
		SceneComponent->AttachToComponent(TankBody, FAttachmentTransformRules::SnapToTargetIncludingScale);
		LeftScene.Add(SceneComponent);
	}

	for (FName &BoneName : RightWheelBone)
	{
		FVector SocketLocation = TankBody->GetSocketLocation(BoneName);
		SocketLocation.Z += 30;
		FTransform SpawnTransform;
		SpawnTransform.SetLocation(UKismetMathLibrary::InverseTransformLocation(GetActorTransform(),SocketLocation));

		/*USceneComponent* SceneComponent = CreateDefaultSubobject<USceneComponent>(BoneName);
		SceneComponent->SetRelativeTransform(SpawnTransform);*/
		USceneComponent* SceneComponent = Cast<USceneComponent>(AddComponentByClass(USceneComponent::StaticClass(), false, SpawnTransform, false));
		SceneComponent->AttachToComponent(TankBody, FAttachmentTransformRules::KeepWorldTransform);
		RightScene.Add(SceneComponent);
	}

	TankMoveComponent->Init(LeftScene, RightScene, TankBody, 2300, 2300);
}

bool ATankPawnBase::GetTurretRotation(float &OutYawRotator, float &OutPitchRotator)
{
	OutYawRotator = TurretYawRotator;
	OutPitchRotator = TurretPitchRotator;
	return bTurretCanRotator;
}

void ATankPawnBase::SetAimLocation(FVector InAimLocation)
{
	AimLocation = InAimLocation;
}

// Called when the game starts or when spawned
void ATankPawnBase::BeginPlay()
{
	Super::BeginPlay();

	InitTankMoveComponent();
}

// Called every frame
void ATankPawnBase::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	bTurretCanRotator = TurretComponent->TargetRotation(DeltaTime, AimLocation, TurretYawRotator, TurretPitchRotator);

	TankMoveComponent->TracksControl(InputForwardValue, InputRightValue);
	//UKismetSystemLibrary::PrintString(this, FString::Printf(TEXT("InputForwardValue:%.2f InputRightValue:%.2f"), InputForwardValue, InputRightValue), true, false, FLinearColor::Red, 0);
	
	if (LastSpawnDustTime<=0)
	{
		SpawnDust();
		LastSpawnDustTime += 0.2;
	}
	LastSpawnDustTime -= DeltaTime;

	UpdateCamera(DeltaTime);
}

// Called to bind functionality to input
void ATankPawnBase::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);
	PlayerInputComponent->BindAxis("LookUp", this, &ATankPawnBase::LookUp);
	PlayerInputComponent->BindAxis("LookRight", this, &ATankPawnBase::LookRight);

	PlayerInputComponent->BindAxis("MoveForward", this, &ATankPawnBase::AddMoveForward);
	PlayerInputComponent->BindAxis("MoveRight", this, &ATankPawnBase::AddMoveRight);

	PlayerInputComponent->BindAction("ZoomUp", IE_Pressed, this, &ATankPawnBase::ZoomUp);
	PlayerInputComponent->BindAction("ZoomDown", IE_Pressed, this, &ATankPawnBase::ZoomDown);

	PlayerInputComponent->BindAction("Aim", IE_Pressed, this, &ATankPawnBase::StartAim);
	PlayerInputComponent->BindAction("Aim", IE_Released, this, &ATankPawnBase::EndAim);

	PlayerInputComponent->BindAction("Fire", IE_Pressed, this, &ATankPawnBase::StartFire);
	PlayerInputComponent->BindAction("Fire", IE_Released, this, &ATankPawnBase::EndFire);

	PlayerInputComponent->BindAction("ReLoad", IE_Pressed, this, &ATankPawnBase::ReLoad);

	PlayerInputComponent->BindAction("AutoAim", IE_Pressed, this, &ATankPawnBase::AutoAim);

	PlayerInputComponent->BindAction("HandBrake", IE_Pressed, this, &ATankPawnBase::StartHandBrake);
	PlayerInputComponent->BindAction("HandBrake", IE_Released, this, &ATankPawnBase::EndHandBrake);

}

void ATankPawnBase::LookUp(float AxisValue)
{
	AddControllerPitchInput(AxisValue);
}

void ATankPawnBase::LookRight(float AxisValue)
{
	AddControllerYawInput(AxisValue);
}

void ATankPawnBase::AddMoveForward(float AxisValue)
{
	InputForwardValue = AxisValue;
}

void ATankPawnBase::AddMoveRight(float AxisValue)
{
	InputRightValue = AxisValue;
}

void ATankPawnBase::ZoomUp()
{
	if (CameraTP->IsActive())
	{
		int a = TargetArmLength / 50;
		a--;
		TargetArmLength = a*50;
	}
	else
	{
		TargetFieldOfView -= 5;
	}
}

void ATankPawnBase::ZoomDown()
{
	if (CameraTP->IsActive())
	{
		int a = TargetArmLength / 50;
		a++;
		TargetArmLength = a * 50;
	}
	else
	{
		TargetFieldOfView += 5;
	}
}

void ATankPawnBase::StartAim()
{
	CameraTP->SetActive(false);
	CameraAim->SetActive(true);
}

void ATankPawnBase::EndAim()
{
	CameraTP->SetActive(true);
	CameraAim->SetActive(false);
}

void ATankPawnBase::StartFire()
{
	FireSystemComponent->StartFire();
}

void ATankPawnBase::EndFire()
{
	FireSystemComponent->EndFire();
}

void ATankPawnBase::ReLoad()
{
	FireSystemComponent->Reload();
}

void ATankPawnBase::AutoAim()
{
	bAutoAim = !bAutoAim;
}

void ATankPawnBase::StartHandBrake()
{
	TankMoveComponent->SetBrake(true);
}

void ATankPawnBase::EndHandBrake()
{
	TankMoveComponent->SetBrake(false);
}
