// Fill out your copyright notice in the Description page of Project Settings.


#include "TankPC.h"
#include "Kismet/GameplayStatics.h"
#include <TankPawnBase.h>
#include <../Tank3GameModeBase.h>

FVector ATankPC::GetAimWorldLocation()
{
	if (TankPawn->bAutoAim)
	{
		ATankPawnBase* EnemyTank = TankGM->GetNearOfDirection(TankPawn->GetActorLocation(), PlayerCameraManager->GetCameraRotation());
		if (IsValid(EnemyTank))
		{
			//UKismetSystemLibrary::PrintString(this, FString::Printf(TEXT("EnemyTank: %s"), *EnemyTank->GetActorLocation().ToString()), true, false, FLinearColor::Red, 0);
			FVector ActorLocation = EnemyTank->GetActorLocation();
			ActorLocation.Z += 200;
			return ActorLocation;
		}
	}

	int SizeX, SizeY;
	GetViewportSize(SizeX, SizeY);
	SizeX /= 2;
	SizeY /= 2;

	FVector StartLocation;
	FVector WorldDirection;
	UGameplayStatics::DeprojectScreenToWorld(this, { (float)SizeX,(float)SizeY }, StartLocation, WorldDirection);

	FVector EndLocation = StartLocation + 10000 * WorldDirection;
	FHitResult OutHit;
	UKismetSystemLibrary::LineTraceSingle(this, StartLocation, EndLocation, UEngineTypes::ConvertToTraceType(ECC_Visibility), false, { TankPawn }, EDrawDebugTrace::None, OutHit, true);
	if (OutHit.bBlockingHit)
	{
		EndLocation = OutHit.Location;
	}
	//UKismetSystemLibrary::DrawDebugSphere(this, EndLocation);
	return EndLocation;
}

void ATankPC::OnPossess(APawn* aPawn)
{
	Super::OnPossess(aPawn);
	TankPawn = Cast<ATankPawnBase>(aPawn);
	check(TankPawn);
	TankGM = Cast<ATank3GameModeBase>(UGameplayStatics::GetGameMode(this));
}

void ATankPC::PlayerTick(float DeltaTime)
{
	Super::PlayerTick(DeltaTime);
	TankPawn->SetAimLocation(GetAimWorldLocation());
}
